#ifndef CONSTANTS_H
#define CONSTANTS_H

void define_constants(PyObject *module);

#endif
