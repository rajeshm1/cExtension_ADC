#try:
#    from overlays import builder
#    builder.compile()
#    builder.copy()
#except:
#    pass

#import distribute_setup
#import io
#import sys
#import platform
#distribute_setup.use_setuptools()
#from setuptools import setup, Extension, find_packages

from distutils.core import setup, Extension
#from Cython.Distutils import build_ext

module = Extension("adcModule", sources = ["adcModule.c"])

#for e in ext_modules:
#	e.cython_directives = {'language_level': "3"}

setup(name		="CExtension_BBIO", 
      version   	= "1.0.0",
      description	="ADC Ext Module for BBIO",
     # ext_modules 	= [Extension('CExtension_BBIO.ADC', ['adc_module.c', 'c_adc.c', 'constants.c', 'common.c'], **extension_args)] )
      ext_modules = [module])  	
