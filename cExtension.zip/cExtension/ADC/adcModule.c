#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include "Python.h"
#include "constants.h"
#include "common.h"
#include "adc_module.h"
#include "error.h"

BBIO_err adc_setup(void);
BBIO_err read_value(unsigned int ain, float *value);
BBIO_err adc_cleanup(void);
BBIO_err get_adc_ain(const char *key, int *ain);
int lookup_ain_by_key(const char *key);
BBIO_err initialize_adc(void);


char adc_prefix_dir[49];
char test_path[149];
int adc_initialized = 0;



typedef struct pins_t {
	const char *name;
	const char *key;
	int gpio;
	int pwm_mux_mode;
	int ain;
} pins_t;

pins_t table[] = {

{ "AIN0", "P9_39", 0, -1, 0},
{ "AIN1", "P9_40", 0, -1, 1},
{ NULL, NULL, 0, 0, 0 }

};


BBIO_err adc_setup(void)
{
	return initialize_adc();
}

BBIO_err initialize_adc()
{
	char test_path[149];
	FILE *fh;
	BBIO_err err;
	
	if (adc_initialized) {
		return BBIO_OK;
	}
	// load device tree is skipped here
	return BBIO_GEN;
}


int lookup_ain_by_key(const char *key)
{
	pins_t *p;
	for (p = table; p->key != NULL; ++p) {
		if(strcmp(p->key,key)== 0){
			if (p->ain == -1) {		
				return -1;
			} else {
				return p->ain;
			}
		}
	}
	return -1;
}

int lookup_ain_by_name(const char *name)
{
	pins_t *p;
	for (p = table; p->name != NULL; ++p) {
		if(strcmp(p->name,name)== 0){
			if (p->ain == -1) {		
				return -1;
			} else {
				return p->ain;
			}
		}
	}
	return -1;
}

BBIO_err get_adc_ain(const char *key, int *ain)
{
	*ain = lookup_ain_by_key(key);

	if (*ain == - 1){
		*ain = lookup_ain_by_name(key);

		if (*ain == -1) {
			return BBIO_INVARG;	
}
}
	return BBIO_OK;
}

BBIO_err read_value(unsigned int ain, float *value)
{
	FILE * fh;
	char ain_path[149];
	snprintf(ain_path, sizeof(ain_path), "%s%d_raw", adc_prefix_dir, ain);
	
	int err, try_count;
	int read_successful;

	read_successful = 0;
	
	while (!read_successful && try_count < 3)
	{
		fh = fopen(ain_path, "r");
		if (!fh){
			return BBIO_SYSFS;	
	}
	fseek(fh, 0, SEEK_SET);
	err = fscanf(fh, "%f", value);
	
	if (err != EOF) read_successful = 1;
	fclose(fh);
	try_count++;
	}
	if (read_successful) return BBIO_OK;
	return BBIO_GEN;
}


// python function setup()

static PyObject *py_setup_adc(__attribute__ ((unused)) PyObject *self, __attribute__ ((unused)) PyObject *args)
{
    BBIO_err err;

    err = adc_setup();
    if (err != BBIO_OK) {
        PyErr_SetString(PyExc_RuntimeError, "Unable to setup ADC system. Possible causes are: \n"
                                        "  - A cape with a conflicting pin mapping is loaded \n"
                                        "  - A device tree object is loaded that uses the same name for a fragment: helper");
        return NULL;
    }

    Py_RETURN_NONE;
}

// python function read(channel)
static PyObject *py_read(__attribute__ ((unused)) PyObject *self, PyObject *args)
{
    int ain;
    float value;
    char *channel;
    PyObject *py_value;
    BBIO_err err;

    if (!PyArg_ParseTuple(args, "s", &channel))
        return NULL;

    // check setup was called prior
    if (!adc_initialized)
    {
        PyErr_SetString(PyExc_RuntimeError, "You must setup() ADC prior to calling read.");
        return NULL;
    }    

    err = get_adc_ain(channel, &ain);
    if (err != BBIO_OK) {
        PyErr_SetString(PyExc_ValueError, "Invalid AIN key or name.");
        return NULL;    
    }

    err = read_value(ain, &value);
    if (err != BBIO_OK) {
        PyErr_SetFromErrnoWithFilename(PyExc_IOError, "Error while reading AIN port. Invalid or locked AIN file.");
        return NULL;
    }

    //scale modifier
#ifdef BBBVERSION41
    value = value / 4095.0;
#else
    value = value / 1800.0;
#endif

    py_value = Py_BuildValue("f", value);

    return py_value;
}

// python function read(channel)
static PyObject *py_read_raw(__attribute__ ((unused)) PyObject *self, PyObject *args)
{
    int ain;
    float value;
    char *channel;
    PyObject *py_value;
    BBIO_err err;

    if (!PyArg_ParseTuple(args, "s", &channel))
        return NULL;

   // check setup was called prior
    if (!adc_initialized)
    {
        PyErr_SetString(PyExc_RuntimeError, "You must setup() ADC prior to calling read.");
        return NULL;
    }       

    err = get_adc_ain(channel, &ain);
   if (err != BBIO_OK) {
        PyErr_SetString(PyExc_ValueError, "Invalid AIN key or name.");
        return NULL;    
    }

    err = read_value(ain, &value);

    if (err != BBIO_OK) {
        PyErr_SetFromErrnoWithFilename(PyExc_IOError, "Error while reading AIN port. Invalid or locked AIN file.");
        return NULL;
    }

    py_value = Py_BuildValue("f", value);

    return py_value;
}

static PyObject* version(PyObject* self)
{
	return Py_BuildValue("s", "Version 1.0");
}

static const char moduledocstring[] = "ADC functionality of a BeagleBone using Python";

PyMethodDef adcMethods[] = {
    {"setup", py_setup_adc, METH_VARARGS, "Set up and start the ADC channel."},
    {"read", (PyCFunction)py_read, METH_VARARGS, "Read the normalized 0-1.0 analog value for the channel" },
    {"read_raw", (PyCFunction)py_read_raw, METH_VARARGS, "Read the raw analog value for the channel" },
    //disable cleanup for now, as unloading the driver locks up the system
    //{"cleanup", py_cleanup, METH_VARARGS, "Clean up ADC."},
    //{"setwarnings", py_setwarnings, METH_VARARGS, "Enable or disable warning messages"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef adcModule = {
    PyModuleDef_HEAD_INIT,
    "adcModule",       // name of module
    "ADC Module",  // module documentation, may be NULL
    -1,               // size of per-interpreter state of the module, or -1 if the module keeps state in global variables.
    adcMethods
};



PyMODINIT_FUNC PyInit_adcModule(void)
{
	return PyModule_Create(&adcModule);
}
