import pytest
import os
import platform
import adcModule

class TestAdc: 

    def test_setup_adc(self):

        adcModule.setup()

        kernel = platform.release()
        if kernel >= '4.1.0':
            test_path = "/sys/bus/iio/devices/iio:device0/in_voltage1_raw"
        else:
            files = os.listdir('/sys/devices')
            ocp = '/sys/devices/'+[s for s in files if s.startswith('ocp')][0]
            files = os.listdir(ocp)
            helper_path = ocp+'/'+[s for s in files if s.startswith('helper')][0]
            test_path = helper_path + "/AIN1"

        assert os.path.exists(test_path);
        #ADC.cleanup()
 
    def test_read_adc(self):
        adcModule.setup()
        value = -1
        value = adcModule.read("P9_40")
#	print(adcModule.read("P9_40"))
#	print(value)
        assert value != -1

    def test_read_raw_adc(self):
        adcModule.setup()
        value = -1
        value = adcModule.read_raw("P9_40")
#	assert value != -1
        return value

obj=TestAdc()
print(obj.test_read_raw_adc())
